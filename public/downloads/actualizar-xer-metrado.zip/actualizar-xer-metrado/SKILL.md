---
name: actualizar-xer-metrado
description: "Actualiza avance físico, Started/Finished, fechas y Data Date de un XER de P6 desde un Excel de metrado, y entrega un informe de project controls (ruta crítica, near-critical, HH ganadas)."
---

# Actualizar XER a partir de metrado ejecutado (Excel)

Esta skill automatiza el flujo de trabajo de Yerson: recibe un Excel de avance de obra (con el metrado ejecutado por actividad, formato "3WLA" del proyecto Tia Maria / SPCC) y un archivo `.xer` exportado de Primavera P6, y devuelve un `.xer` actualizado con: % de avance físico, Started/Finished (status_code + fechas reales), Remaining Duration proyectado según rendimiento real, y Data Date movido a la fecha de corte. Además entrega, en el chat, un **informe estructurado de project controls senior** (ver plantilla abajo) con avance ponderado, Budgeted/Earned Labor Units, ruta crítica, near-critical, progreso fuera de secuencia y calidad de datos. Falta correr Schedule/F9 en P6 después de importar (ver Notas).

## Cuándo usar esta skill

Usar siempre que el usuario pida "actualizar el XER", "subir avance a P6", "cruzar el metrado con el cronograma", "actualizar Started/Finished", "actualizar remaining duration", "afectación en ruta crítica", "reporte de actualización", "budgeted labor units", "earned hours" o entregue un Excel de metrado junto con (o para actualizar) un archivo `.xer`. Si el usuario pide una extensión nueva sobre un XER que ya se había actualizado antes en la conversación, **siempre volver a trabajar desde el XER ORIGINAL** que envió el usuario, no sobre una versión ya modificada — aplicar TODOS los cambios acumulados en una sola pasada limpia. El formato del informe (plantilla de la sección "Informe de actualización") es el default para toda actualización futura salvo que el usuario pida otra cosa — entregarlo como mensaje estructurado en el chat (Markdown con tablas), no como archivo, salvo que el usuario pida explícitamente un Word/Excel.

## Insumos esperados

1. **Archivo XER** (`.xer`): exportación de Primavera P6. Texto plano delimitado por tabulaciones, líneas `\r\n`, encoding `cp1252`, organizado en tablas (`%T` tabla, `%F` campos, `%R` fila, `%E` fin). Tablas y campos relevantes:
   - `TASK`: `task_id`, `task_code` (Activity ID / "ID P6"), `phys_complete_pct` (escala **0-100**), `complete_pct_type` (`CP_Drtn`/`CP_Phys`/`CP_Units`), `status_code` (`TK_NotStart`/`TK_Active`/`TK_Complete`), `act_start_date`, `act_end_date`, `remain_drtn_hr_cnt`, `target_start_date`, `target_end_date`, `early_start_date`, `early_end_date`, `total_float_hr_cnt`, `driving_path_flag`, `target_work_qty` (**Budgeted Labor Units** de la actividad, en HH — es el mismo dato que P6 muestra en la columna "Budgeted Labor Units"; usarlo como peso para el avance ponderado global y para el reporte de Earned Labor Units, ver sección de informe), `clndr_id`.
   - `PROJECT`: una fila por proyecto. Data Date = `last_recalc_date` (`YYYY-MM-DD HH:MM`).
   - `CALENDAR`: `clndr_id` -> `day_hr_cnt` (horas/día) y patrón semanal (`clndr_data`, `DaysOfWeek`, `Exceptions`).

2. **Excel de avance** (formato "3WLA"): verificar SIEMPRE la estructura real antes de asumir posiciones de columna:
   - Hoja tipo `3WLA` (preguntar si no aparece con ese nombre).
   - Encabezados reales en la fila ~10 (hay filas de títulos combinados arriba).
   - Columna `Tipo`: **NO asumir que solo `'Actividad'` trae metrado**. En Tia María, el desglose real de las 34 torres viene con `Tipo = 'Partida'` (~3190 filas), y solo la gestión/procura con `Tipo = 'Actividad'` (~138) — **ambos deben procesarse**. Solo excluir `Tipo == 'WBS'` y basura. Contar valores únicos de `Tipo` (`Counter`) antes de fijar el filtro.
   - Columna `ID P6` = Activity ID, cruza exacto con `task_code`.
   - **Cuidado con ID P6 duplicados/ambiguos**: agrupar por `ID P6` y detectar filas con `Descripción de la Actividad` distinta para el mismo código (p.ej. "conductores" vs "cables FO" reutilizando la misma secuencia). **Nunca sumar automáticamente** — excluir y listar en el informe (sección Calidad de Datos).
   - Columnas `Metrado Total PPTO` y `Metrado Total FCT 01`: usar **FCT** como denominador salvo pedido explícito de usar PPTO.
   - Bloques **PLANIFICADO** y **REAL**, una columna por día calendario (no por semana, aunque diga "SEMANA XX"). **Cuidado con fechas cacheadas por Excel**: con `openpyxl(read_only=True, data_only=True)` las fechas de columnas por fórmula (`=MAX(rango)+1`) pueden venir desactualizadas — si no forman secuencia diaria limpia, abrir con `data_only=False`, ubicar la fórmula de arranque del bloque y calcular las fechas sumando días consecutivos.
   - Actividades sin metrado (hitos) suelen tener `Metrado Total` en 0/vacío: excluir del cálculo, es normal.

## Pasos

1. **Inspeccionar el Excel antes de asumir nada**: hojas, encabezados reales, `Counter` de `Tipo`.
2. **Detectar y excluir ID P6 duplicados/ambiguos** antes de calcular. Guardar para el informe.
3. **Ubicar la columna de corte** en el bloque REAL (y PLANIFICADO de referencia).
4. **Calcular metrado ejecutado acumulado** por actividad (suma diaria del bloque REAL hasta el corte), sobre `Tipo` válido.
5. **Calcular % de avance**: `pct = ejecutado/total*100`, acotado [0,100], con tolerancia `[100-1e-4, 100]` -> 100 exacto (error de punto flotante al sumar decimales largos), y misma tolerancia en `cum >= total - 1e-6` para detectar fecha de cumplimiento.
6. **Calcular Started/Finished**: `fecha_inicio_real`/`fecha_fin_real` por cruce de acumulado diario vs. total. Si caen en el primer día visible del bloque REAL y la fecha planificada es anterior, usar la planificada como estimado (marcar como tal). `status_code` según pct. Escribir `act_start_date`/`act_end_date` con hora del calendario del proyecto.
7. **Detectar progreso fuera de secuencia**: comparar `fecha_inicio_real` calculada contra `early_start_date` **original** (antes de esta actualización) de esa actividad. Si `fecha_inicio_real < early_start_date_original`, es fuera de secuencia — contar y guardar para el informe (sección 6 de la plantilla). Esto se ha visto en volúmenes grandes (>200 actividades, con brechas de meses) — no es un bug, es una señal real de desalineación entre campo y lógica de predecesoras; reportarlo siempre, no descartarlo como ruido.
8. **Calcular Remaining Duration proyectado** (solo `TK_Active`): `rendimiento_diario = ejecutado/dias_transcurridos`; `dias_restantes = ceil((total-ejecutado)/rendimiento_diario)`; `remain_drtn_hr_cnt = dias_restantes * horas_dia_calendario` (leer `day_hr_cnt` de `CALENDAR`, no asumir 8h). `TK_Complete` -> 0. `TK_NotStart` -> no tocar.
9. **Revisar `complete_pct_type`**: si no es `CP_Phys` (común: `CP_Drtn`), preguntar si cambiarlo — si no, P6 no refleja el nuevo `phys_complete_pct` visualmente.
10. **Preguntar por el Data Date**: actualizar `last_recalc_date` en `PROJECT` a la fecha de corte si el usuario acepta (verificar cuántas filas tiene `PROJECT`).
11. **Calcular Budgeted / Earned Labor Units y el avance físico ponderado global**, usando `target_work_qty` (Budgeted Labor Units, HH) de cada actividad como peso — NUNCA promediar o sumar `Metrado Total` directamente entre actividades porque mezclan unidades distintas (m3, km, glb, und...). Para cada actividad: `HH_earned_i = HH_budget_i * pct_i / 100`. Reportar, desglosado por status (NotStart/Active/Complete) y en total: `HH_budget` (Budgeted Labor Units) y `HH_earned` (Actual/Earned Labor Units), tanto de las actividades actualizadas como del proyecto completo (sumando el `phys_complete_pct` previo de las no actualizadas). `% avance ponderado = HH_earned_total / HH_budget_total * 100`. Ver funcion `avance_ponderado_hh` en el script de referencia.
12. **Parsear y escribir el XER preservando su estructura exacta**. Verificar mismo número de líneas que el original.
13. **Calcular ruta crítica y near-critical**: usar `total_float_hr_cnt`/`driving_path_flag` **del XER de entrada** (no se recalcula el CPM aquí). Crítica = `driving_path=='Y'` o `float<=0`. Near-critical = `0 < float <= umbral` (**default 5 días = 40h**, confirmar con el usuario si aplica otro umbral la primera vez en cada proyecto).
14. **Entregar el archivo** `.xer` en `/mnt/user-data/outputs/` vía `SendUserFile` (no se autoentrega al escribirlo por script) y guardarlo en la carpeta conectada si hay una, sufijo `_actualizado`.
15. **Entregar el informe** siguiendo la plantilla de la sección siguiente, como mensaje en el chat (Markdown con tablas), salvo que el usuario pida un archivo.

## Informe de actualización — plantilla estándar (project controls senior)

Entregar SIEMPRE con esta estructura, en este orden, con tablas Markdown donde se indique. Omitir una sección solo si no aplica (ej. sin fuera de secuencia), pero nunca sin decirlo ("sin hallazgos" en vez de omitir silenciosamente).

```
# Informe de Actualización de Cronograma — <nombre proyecto>
**Corte:** <fecha> | **Data Date:** <anterior> → <nuevo> | **Fuente:** <excel/hoja> vs. <xer>

## 1. Resumen Ejecutivo
- Tabla: actividades actualizadas / cobertura HH% / avance ponderado global (Earned/Budgeted Labor Units) / # criticas / # near-critical / # fuera de secuencia / # excluidas.
- 2-3 lineas de lectura rapida (estado general, el hallazgo mas relevante).

## 2. Estado del Cronograma
- Data Date antes/despues.
- Distribucion de actividades por status (NotStart/Active/Complete), cantidad y %.
- Aviso de que falta correr Schedule (F9).

## 3. Avance Fisico — Budgeted vs Earned Labor Units
- Tabla por status (NotStart/Active/Complete): HH Budgeted, HH Earned, % del budget de ese grupo.
- Totales: HH Budgeted y HH Earned de lo actualizado, y de todo el proyecto (incluyendo actividades no tocadas en este corte con su pct anterior).
- % Avance representativo del proyecto = HH Earned total / HH Budgeted total.

## 4. Ruta Critica
- Tabla de actividades criticas actualizadas mas relevantes (con avance real primero, luego las en 0% mas criticas por impacto).
- Lectura de riesgo (cuales protegen la ruta, cuales la amenazan).
- Nota: float basado en el ultimo Schedule corrido, no recalculo propio.

## 5. Near-Critical Path
- Tabla o resumen de las actividades con holgura <= umbral, con frentes/patrones identificados.

## 6. Progreso Fuera de Secuencia (solo si hay casos)
- Cantidad total, ejemplos con mayor brecha (fecha real vs early_start original).
- Explicacion de las dos lecturas posibles (campo adelantado vs logica desactualizada) y recomendacion de revisar predecesoras / definir Retained Logic vs Progress Override.

## 7. Calidad de Datos — Exclusiones
- Tabla: motivo, cantidad, accion sugerida (ID P6 duplicado, sin metrado total, inicio/fin estimado no confirmado).

## 8. Recomendaciones
- Lista corta y accionable (correr F9, decidir tratamiento fuera de secuencia, corregir Excel, priorizar actividades criticas en 0%, reenviar XER post-Schedule para comparacion real).
```

## Script de referencia (parser/writer de XER + cálculos)

Adaptar nombres de hoja/columnas al archivo real — no asumir índices fijos sin verificarlos primero.

```python
import openpyxl, math, datetime

def leer_excel_metrado(ruta_excel, hoja, fila_header, idx_tipo, idx_activity_id, idx_desc,
                        idx_metrado_total, real_start_idx, real_cutoff_idx, tipos_validos):
    """tipos_validos: verificar con Counter antes -- nunca asumir que es solo 'Actividad'."""
    wb = openpyxl.load_workbook(ruta_excel, data_only=True, read_only=True)
    ws = wb[hoja]
    registros, duplicados = {}, {}
    for row in ws.iter_rows(min_row=fila_header + 1, values_only=True):
        if row[idx_tipo] not in tipos_validos:
            continue
        activity_id = row[idx_activity_id]
        if activity_id is None:
            continue
        activity_id = str(activity_id).strip()
        desc, total = row[idx_desc], row[idx_metrado_total]
        real_vals = list(row[real_start_idx:real_cutoff_idx + 1])
        ejecutado = sum(v for v in real_vals if isinstance(v, (int, float)))
        if activity_id in registros:
            duplicados.setdefault(activity_id, [registros[activity_id]['desc']]).append(desc)
            registros[activity_id]['conflicto'] = True
        else:
            registros[activity_id] = {'total': total, 'ejecutado': ejecutado, 'desc': desc,
                                       'diarios': real_vals, 'conflicto': False}
    return registros, duplicados


def calcular_pct(registros):
    pct_por_actividad, sin_total = {}, []
    for code, d in registros.items():
        if d.get('conflicto'):
            continue
        total = d['total']
        if not total or not isinstance(total, (int, float)) or total == 0:
            sin_total.append(code)
            continue
        pct = max(0.0, min(100.0, d['ejecutado'] / total * 100))
        if pct >= 100 - 1e-4:
            pct = 100.0
        pct_por_actividad[code] = pct
    return pct_por_actividad, sin_total


def calcular_started_finished(diarios, total, fecha_inicio_ventana, target_start, target_end, fecha_corte,
                               early_start_original=None, horas_dia=8):
    EPS = 1e-6
    cum, fecha_inicio_real, fecha_fin_real = 0.0, None, None
    for k, val in enumerate(diarios):
        v = val if isinstance(val, (int, float)) else 0
        if v > 0 and fecha_inicio_real is None:
            fecha_inicio_real = fecha_inicio_ventana + datetime.timedelta(days=k)
        cum += v
        if fecha_fin_real is None and total and cum >= total - EPS:
            fecha_fin_real = fecha_inicio_ventana + datetime.timedelta(days=k)

    inicio_estimado = fin_estimado = False
    if fecha_inicio_real == fecha_inicio_ventana and target_start and target_start < fecha_inicio_ventana:
        fecha_inicio_real, inicio_estimado = target_start, True
    if fecha_fin_real == fecha_inicio_ventana and target_end and target_end < fecha_inicio_ventana:
        fecha_fin_real, fin_estimado = target_end, True

    fuera_de_secuencia = bool(early_start_original and fecha_inicio_real and fecha_inicio_real < early_start_original)

    pct = max(0.0, min(100.0, cum / total * 100)) if total else 0.0
    if pct >= 100 - 1e-4:
        pct = 100.0

    rendimiento = dias_transc = remaining_days = remain_hr = None
    if pct >= 100 - EPS:
        status, remain_hr = 'TK_Complete', 0
    elif pct <= EPS:
        status = 'TK_NotStart'
    else:
        status = 'TK_Active'
        if fecha_inicio_real is not None:
            dias_transc = (fecha_corte - fecha_inicio_real).days + 1
            if dias_transc > 0 and cum > 0:
                rendimiento = cum / dias_transc
                remaining_days = math.ceil((total - cum) / rendimiento)
                remain_hr = remaining_days * horas_dia

    return dict(status=status, fecha_inicio_real=fecha_inicio_real, inicio_estimado=inicio_estimado,
                fecha_fin_real=fecha_fin_real, fin_estimado=fin_estimado, remain_hr=remain_hr,
                fuera_de_secuencia=fuera_de_secuencia)


def budgeted_earned_labor_units(resultados, hh_por_actividad, phys_complete_pct_original_por_codigo,
                                 hh_total_proyecto):
    """Calcula Budgeted/Earned Labor Units (HH) por status y en total, para lo actualizado y para
    todo el proyecto (usando phys_complete_pct ORIGINAL -- antes de esta actualizacion -- para las
    actividades que esta pasada no toco). NUNCA ponderar con Metrado Total (mezcla unidades); siempre
    con target_work_qty (Budgeted Labor Units).
    resultados: {code: {'pct':..., 'status':...}}. hh_por_actividad: {code: target_work_qty (TODAS las
    actividades del XER, no solo las actualizadas)}. phys_complete_pct_original_por_codigo: {code: pct}
    para TODAS las actividades del XER de entrada (el valor que tenian antes de este update).
    """
    por_status_budget = {'TK_NotStart': 0.0, 'TK_Active': 0.0, 'TK_Complete': 0.0}
    por_status_earned = {'TK_NotStart': 0.0, 'TK_Active': 0.0, 'TK_Complete': 0.0}
    hh_actualizadas = earned_actualizadas = 0.0
    earned_proyecto = 0.0

    for code, hh in hh_por_actividad.items():
        if code in resultados:
            r = resultados[code]
            por_status_budget[r['status']] += hh
            earned = hh * r['pct'] / 100
            por_status_earned[r['status']] += earned
            hh_actualizadas += hh
            earned_actualizadas += earned
            earned_proyecto += earned
        else:
            pct0 = phys_complete_pct_original_por_codigo.get(code, 0.0)
            earned_proyecto += hh * pct0 / 100

    pct_actualizadas = earned_actualizadas / hh_actualizadas * 100 if hh_actualizadas else None
    pct_proyecto = earned_proyecto / hh_total_proyecto * 100 if hh_total_proyecto else None

    return dict(por_status_budget=por_status_budget, por_status_earned=por_status_earned,
                hh_budget_actualizadas=hh_actualizadas, hh_earned_actualizadas=earned_actualizadas,
                pct_actualizadas=pct_actualizadas, hh_budget_proyecto=hh_total_proyecto,
                hh_earned_proyecto=earned_proyecto, pct_proyecto=pct_proyecto)


def reporte_criticidad(codigos_actualizados, resultados, xer_lineas_originales, umbral_dias=5, horas_dia=8):
    """xer_lineas_originales: lineas del XER de ENTRADA (no el ya modificado)."""
    umbral_hr = umbral_dias * horas_dia
    in_task, campos, idx = False, [], {}
    info = {}
    for l in xer_lineas_originales:
        if l.startswith('%T'):
            in_task = l.split('\t', 1)[1].strip() == 'TASK'
            continue
        if in_task and l.startswith('%F'):
            campos = l.split('\t')[1:]
            idx = {c: i for i, c in enumerate(campos)}
            continue
        if in_task and l.startswith('%R'):
            parts = l.split('\t')[1:]
            code = parts[idx['task_code']].strip()
            if code in codigos_actualizados:
                try:
                    tf = float(parts[idx['total_float_hr_cnt']]) if parts[idx['total_float_hr_cnt']] != '' else None
                except ValueError:
                    tf = None
                info[code] = {'total_float_hr': tf, 'driving': parts[idx['driving_path_flag']] == 'Y'}

    criticas, near = [], []
    for code, r in resultados.items():
        inf = info.get(code)
        if inf is None:
            continue
        tf = inf['total_float_hr']
        if inf['driving'] or (tf is not None and tf <= 0):
            criticas.append((code, r, inf))
        elif tf is not None and tf <= umbral_hr:
            near.append((code, r, inf))
    return criticas, near


def actualizar_xer(ruta_xer, ruta_salida, resultados_por_actividad, hora_inicio='09:00', hora_fin='17:00',
                    cambiar_a_fisico=True, nuevo_data_date=None):
    with open(ruta_xer, 'r', encoding='cp1252', errors='replace') as f:
        text = f.read()
    usa_crlf = '\r\n' in text
    lineas = text.split('\r\n') if usa_crlf else text.split('\n')

    idx = idx_p = {}
    in_task = in_project = False
    project_line_idx = None

    for i, linea in enumerate(lineas):
        if linea.startswith('%T'):
            tabla = linea.split('\t', 1)[1].strip()
            in_task, in_project = tabla == 'TASK', tabla == 'PROJECT'
            continue
        if in_task and linea.startswith('%F'):
            campos = linea.split('\t')[1:]
            idx = {c: k for k, c in enumerate(campos)}
            continue
        if in_task and linea.startswith('%R'):
            partes = linea.split('\t')
            code = partes[idx['task_code'] + 1].strip()
            r = resultados_por_actividad.get(code)
            if r:
                partes[idx['phys_complete_pct'] + 1] = f"{round(r['pct'], 4):g}"
                if cambiar_a_fisico and partes[idx['complete_pct_type'] + 1] != 'CP_Phys':
                    partes[idx['complete_pct_type'] + 1] = 'CP_Phys'
                partes[idx['status_code'] + 1] = r['status']
                if r.get('fecha_inicio_real') is not None:
                    partes[idx['act_start_date'] + 1] = f"{r['fecha_inicio_real'].isoformat()} {hora_inicio}"
                if r.get('fecha_fin_real') is not None:
                    partes[idx['act_end_date'] + 1] = f"{r['fecha_fin_real'].isoformat()} {hora_fin}"
                if r['status'] == 'TK_Complete':
                    partes[idx['remain_drtn_hr_cnt'] + 1] = '0'
                elif r['status'] == 'TK_Active' and r.get('remain_hr') is not None:
                    partes[idx['remain_drtn_hr_cnt'] + 1] = str(r['remain_hr'])
                lineas[i] = '\t'.join(partes)
            continue
        if in_project and linea.startswith('%F'):
            campos_p = linea.split('\t')[1:]
            idx_p = {c: k for k, c in enumerate(campos_p)}
            continue
        if in_project and linea.startswith('%R') and nuevo_data_date and project_line_idx is None:
            project_line_idx = i
            partes = linea.split('\t')
            anterior = partes[idx_p['last_recalc_date'] + 1]
            hora = anterior.split(' ')[1] if ' ' in anterior else '00:00'
            partes[idx_p['last_recalc_date'] + 1] = f"{nuevo_data_date} {hora}"
            lineas[i] = '\t'.join(partes)

    with open(ruta_salida, 'w', encoding='cp1252', errors='replace', newline='') as f:
        sep = '\r\n' if usa_crlf else '\n'
        f.write(sep.join(lineas))
```

## Notas importantes

- Nunca reescribir el XER completo "a mano": partir siempre del original y modificar solo lo necesario línea por línea. Verificar mismo número de líneas en la salida.
- `phys_complete_pct` se escribe en escala **0-100**, no fracción.
- **No asumir que solo un valor de `Tipo` trae metrado**: contar valores únicos primero ("Actividad" y "Partida" ambos aplican en Tia María).
- **Nunca sumar automáticamente** cantidades de filas con el mismo `ID P6` pero descripción distinta — excluir y avisar.
- **Nunca promediar o sumar `Metrado Total` de actividades distintas para sacar un avance global** — mezclan unidades (m3, km, glb, und). Usar `target_work_qty` (Budgeted Labor Units, HH) como peso común, y reportar siempre Budgeted vs Earned Labor Units (ver sección 3 del informe) — no solo el %.
- Al pedir una nueva funcionalidad sobre un XER ya entregado antes, volver a partir del XER **original** y reaplicar todo junto.
- Si el XER trae múltiples proyectos y el Excel no distingue proyecto, confirmar a cuál aplica el metrado (y lo mismo para el Data Date si `PROJECT` tiene más de una fila).
- **El Schedule (F9) no se puede "marcar" ni simular desde el XER**: avisar siempre que hay que correrlo después de importar.
- **Progreso fuera de secuencia**: reportarlo siempre con el conteo real y ejemplos de mayor brecha, aunque sean cientos de actividades — es una señal de negocio real (campo adelantado o lógica de predecesoras desactualizada), no ruido a descartar.
- **Informe de actualización**: usar SIEMPRE la plantilla de la sección "Informe de actualización" de esta skill, como mensaje en el chat con tablas Markdown, salvo que el usuario pida explícitamente un archivo (Word/Excel/PDF).
- Si además se pide actualizar fechas reales o duración restante de forma distinta a la lógica de rendimiento aquí descrita, seguir el mismo patrón: ubicar el índice de columna en `%F TASK` y escribir el valor en la posición correspondiente de cada `%R` que haga match por `task_code`.